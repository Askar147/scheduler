Prerequisites:
1) Install Docker: https://docs.docker.com/engine/install/ubuntu/
2) Install Docker Compose: https://docs.docker.com/compose/install/
3) Clone the project and compose the docker image:\
`docker-compose up`
