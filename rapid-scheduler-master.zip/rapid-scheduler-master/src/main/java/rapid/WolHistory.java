package rapid;

public class WolHistory {
    private long wolid;
    private long vmmid;
    private int iswol;


    public long getWolid() {
        return wolid;
    }

    public void setWolid(long wolid) {
        this.wolid = wolid;
    }

    public long getVmmid() {
        return vmmid;
    }

    public void setVmmid(long vmmid) {
        this.vmmid = vmmid;
    }

    public int getIswol() {
        return iswol;
    }

    public void setIswol(int iswol) {
        this.iswol = iswol;
    }
}
